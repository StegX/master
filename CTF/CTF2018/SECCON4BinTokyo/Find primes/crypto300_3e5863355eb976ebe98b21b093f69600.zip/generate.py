from Crypto.Util.number import *
import random

FLAG = bytes_to_long(<secret>)

ps = [ getPrime(1024) for _ in range(10) ]
qs = [ getPrime(1024) for _ in range(9) ]
qs.append(ps[0])

e = 65537

random.shuffle(ps)
random.shuffle(qs)

for i in range(10):
    N = ps[i] * qs[i]
    C = pow(FLAG, e, N)
    print(N, C)
