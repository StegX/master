if necessary��
$chmod 700 executable_filename
