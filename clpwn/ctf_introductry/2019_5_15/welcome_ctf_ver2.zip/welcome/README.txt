flag format is clpwn{...}.

there is the flag in flag_*.txt.

$cat filename
this is useful.