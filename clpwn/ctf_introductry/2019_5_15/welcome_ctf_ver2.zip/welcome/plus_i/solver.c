#include <stdio.h>

int main(void)
{
	char flag[]="cmrzr{XzyQwq^kPotcrd}";
	int i,k=0;

	for(i=0;i<=256;i++){
		if(flag[i] <= 20 || flag[i] >= 127)
			break;
		if(flag[i] == 123 || flag[i] == 125){
			k++;
			continue;
		}
		flag[i] = flag[i]-i+k;
	}
	printf("%s\n",flag);
	return 0;
}
