There isn't Brutus. But...
problem file:plus_i.pdf

hint:ASCII